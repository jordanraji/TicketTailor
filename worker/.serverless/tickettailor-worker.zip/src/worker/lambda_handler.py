import asyncio
import json
import logging
import sys
from typing import Any, cast

from aws_lambda_powertools.utilities.parser import parse
from aws_lambda_powertools.utilities.parser.envelopes import SnsSqsEnvelope, SqsEnvelope

from worker.adapters.email import get_email_provider
from worker.adapters.web_push import WebPushProvider
from worker.config import settings
from worker.handler import process_domain_event
from worker.schemas import DomainEvent

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("worker.lambda_handler")

# Initialize providers outside the handler.
# This takes advantage of AWS Lambda container reuse (warm starts)
# to preserve HTTP client connections.
email_provider = get_email_provider(
    email_provider_type=settings.EMAIL_PROVIDER,
    from_address=settings.EMAIL_FROM_ADDRESS,
    resend_api_key=settings.RESEND_API_KEY,
    smtp_host=settings.SMTP_HOST,
    smtp_port=settings.SMTP_PORT,
)
push_provider = WebPushProvider(
    private_key=settings.VAPID_PRIVATE_KEY,
    claims_email=settings.VAPID_CLAIMS_EMAIL,
)


def get_envelope(event: dict[str, Any]) -> Any:
    """Dynamically determine the envelope type based SQS records structure."""
    try:
        records = event.get("Records", [])
        if records:
            first_body = json.loads(records[0].get("body", "{}"))
            if (
                isinstance(first_body, dict)
                and "Message" in first_body
                and "TopicArn" in first_body
            ):
                logger.info("SNS wrapper envelope (SnsSqsEnvelope) detected.")
                return SnsSqsEnvelope
    except Exception:
        pass
    logger.info("Raw SQS message envelope (SqsEnvelope) detected.")
    return SqsEnvelope


async def process_parsed_events(parsed_events: list[DomainEvent]) -> None:
    """Process a batch of DomainEvent objects asynchronously."""
    for event in parsed_events:
        logger.info(f"Processing event: {event.event_type}")
        await process_domain_event(
            event_type=event.event_type,
            payload=event.payload,
            email_provider=email_provider,
            push_provider=push_provider,
        )


def run_coroutine(coro: Any) -> Any:
    """Run an async coroutine synchronously.

    If an event loop is already running in the current thread (e.g. in pytest),
    it runs the coroutine in a separate thread to avoid event loop conflicts.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import threading

        result = []
        exception = []

        def target() -> None:
            try:
                result.append(asyncio.run(coro))
            except Exception as e:
                exception.append(e)

        thread = threading.Thread(target=target)
        thread.start()
        thread.join()

        if exception:
            raise exception[0]
        return result[0] if result else None
    else:
        return asyncio.run(coro)


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """AWS Lambda entry point for SQS Event Source Mapping trigger."""
    records = event.get("Records", [])
    if not records:
        logger.info("No records received in Lambda event trigger.")
        return {"statusCode": 200, "body": "No records to process"}

    logger.info(f"Lambda triggered with batch of {len(records)} SQS records.")

    envelope = get_envelope(event)

    try:
        parsed_events = cast(
            list[DomainEvent],
            parse(
                event=event,
                model=DomainEvent,
                envelope=envelope,
            ),
        )
    except Exception as e:
        logger.error(f"Failed to parse event batch using Powertools: {e}")
        raise e

    run_coroutine(process_parsed_events(parsed_events))

    return {
        "statusCode": 200,
        "body": f"Successfully processed {len(records)} records.",
    }
