import asyncio
import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Protocol

import httpx

logger = logging.getLogger(__name__)


class EmailProvider(Protocol):
    async def send_email(
        self, to_address: str, subject: str, html_content: str
    ) -> None:
        """Send an email asynchronously."""
        ...


class SmtpProvider:
    def __init__(self, host: str, port: int, from_address: str):
        self.host = host
        self.port = port
        self.from_address = from_address

    async def send_email(
        self, to_address: str, subject: str, html_content: str
    ) -> None:
        """Send an email using SMTP client via thread pool to avoid blocking."""
        await asyncio.to_thread(self._send, to_address, subject, html_content)

    def _send(self, to_address: str, subject: str, html_content: str) -> None:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = self.from_address
        msg["To"] = to_address

        part = MIMEText(html_content, "html")
        msg.attach(part)

        logger.info(
            f"Sending SMTP email from {self.from_address} to {to_address} "
            f"(via {self.host}:{self.port})"
        )
        with smtplib.SMTP(self.host, self.port) as server:
            server.sendmail(self.from_address, to_address, msg.as_string())


class ResendProvider:
    def __init__(self, api_key: str, from_address: str):
        self.api_key = api_key
        self.from_address = from_address
        self.url = "https://api.resend.com/emails"

    async def send_email(
        self, to_address: str, subject: str, html_content: str
    ) -> None:
        """Send an email using Resend API."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "from": self.from_address,
            "to": to_address,
            "subject": subject,
            "html": html_content,
        }
        logger.info(
            f"Sending Resend API email from {self.from_address} to {to_address}"
        )
        async with httpx.AsyncClient() as client:
            response = await client.post(self.url, json=payload, headers=headers)
            if response.status_code >= 400:
                logger.error(
                    f"Failed to send email via Resend: "
                    f"{response.status_code} {response.text}"
                )
                response.raise_for_status()


def get_email_provider(
    email_provider_type: str,
    from_address: str,
    resend_api_key: str | None,
    smtp_host: str,
    smtp_port: int,
) -> EmailProvider:
    """Factory to get the configured email provider."""
    if email_provider_type.lower() == "resend":
        if not resend_api_key:
            raise ValueError(
                "RESEND_API_KEY is required when EMAIL_PROVIDER is 'resend'"
            )
        return ResendProvider(api_key=resend_api_key, from_address=from_address)
    else:
        return SmtpProvider(host=smtp_host, port=smtp_port, from_address=from_address)
